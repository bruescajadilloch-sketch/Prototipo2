import { useState, useMemo } from "react";
import { motion } from "motion/react";
import { Search, Filter, Calendar, Award, Receipt, ArrowUpDown } from "lucide-react";
import { Sale } from "../types";

interface SalesHistoryListProps {
  sales: Sale[];
  onViewReceipt: (sale: Sale) => void;
}

export default function SalesHistoryList({ sales, onViewReceipt }: SalesHistoryListProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [storeFilter, setStoreFilter] = useState("all");
  const [docTypeFilter, setDocTypeFilter] = useState("all");
  const [sortAsc, setSortAsc] = useState(false);

  // List unique stores for filter
  const uniqueStores = useMemo(() => {
    return ["all", ...Array.from(new Set(sales.map((s) => s.store)))];
  }, [sales]);

  // Filter and Sort sales
  const processedSales = useMemo(() => {
    let filtered = [...sales];

    // Search term
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (s) =>
          s.docNumber.toLowerCase().includes(term) ||
          s.clientName.toLowerCase().includes(term) ||
          s.clientDoc.includes(term) ||
          s.product.toLowerCase().includes(term)
      );
    }

    // Store filter
    if (storeFilter !== "all") {
      filtered = filtered.filter((s) => s.store === storeFilter);
    }

    // Doc Type filter
    if (docTypeFilter !== "all") {
      filtered = filtered.filter((s) => s.docType === docTypeFilter);
    }

    // Sort by timestamp
    filtered.sort((a, b) => {
      const dateA = new Date(a.timestamp).getTime();
      const dateB = new Date(b.timestamp).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

    return filtered;
  }, [sales, searchTerm, storeFilter, docTypeFilter, sortAsc]);

  return (
    <motion.div
      id="sales-history-card"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-slate-200 rounded-xl shadow-sm p-5"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-100">
        <div>
          <h3 className="font-bold text-slate-850 flex items-center gap-1.5 leading-none">
            <Receipt className="w-4 h-5 text-blue-500" /> Registro Histórico de Comprobantes (SEE)
          </h3>
          <p className="text-[11px] text-slate-400 mt-1 font-sans">Bitácora inalterable de auditoría tributaria local</p>
        </div>
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-semibold font-sans">Resultados:</span>
          <span className="font-mono font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded">
            {processedSales.length} emitidos
          </span>
        </div>
      </div>

      {/* FILTER CONTROLS */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-4">
        <div className="sm:col-span-2 relative">
          <input
            type="text"
            placeholder="Buscar por Nº comprobante, RUC/DNI o cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs border border-slate-200 rounded-lg pl-9 pr-3 py-2.5 focus:outline-none focus:border-blue-505 focus:ring-1 focus:ring-blue-500 bg-slate-50/25 text-slate-705"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3.5" />
        </div>

        <div>
          <select
            value={storeFilter}
            onChange={(e) => setStoreFilter(e.target.value)}
            className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-blue-500 bg-white text-slate-700"
          >
            <option value="all">Ver todas las sedes</option>
            {uniqueStores.filter(st => st !== "all").map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={docTypeFilter}
            onChange={(e) => setDocTypeFilter(e.target.value)}
            className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-blue-500 bg-white text-slate-700"
          >
            <option value="all">Facturas y Boletas</option>
            <option value="Factura">Solo Facturas (F001)</option>
            <option value="Boleta">Solo Boletas (B001)</option>
          </select>
        </div>
      </div>

      {/* SALES TABLE */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-gray-100 text-gray-500 font-bold bg-slate-50/50">
              <th className="p-3">Comprobante / Local</th>
              <th className="p-3">Adquirente / Documento</th>
              <th className="p-3">Concepto / Cantidad</th>
              <th className="p-3 text-right">Base Imp.</th>
              <th className="p-3 text-right">IGV (18%)</th>
              <th className="p-3 text-right">
                <button
                  type="button"
                  onClick={() => setSortAsc(!sortAsc)}
                  className="flex items-center space-x-1 hover:text-blue-600 ml-auto"
                >
                  <span>Monto Total</span>
                  <ArrowUpDown className="w-3 h-3" />
                </button>
              </th>
              <th className="p-3 text-center">Estado SUNAT</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {processedSales.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-gray-400">
                  Ningún comprobante emitido coincide con los filtros especificados.
                </td>
              </tr>
            ) : (
              processedSales.map((sale) => (
                <tr key={sale.docNumber} className="hover:bg-slate-50/30 transition-colors">
                  <td className="p-3">
                    <button
                      onClick={() => onViewReceipt(sale)}
                      className="font-bold text-blue-600 hover:text-blue-800 transition-colors uppercase block underline decoration-dotted cursor-pointer"
                    >
                      {sale.docNumber}
                    </button>
                    <span className="text-[10px] text-gray-400 font-medium block mt-0.5">{sale.store}</span>
                  </td>
                  <td className="p-3 max-w-[180px]">
                    <span className="font-semibold text-gray-700 truncate block" title={sale.clientName}>
                      {sale.clientName}
                    </span>
                    <span className="text-[10px] font-mono text-gray-400 block mt-0.5">
                      {sale.clientType}: {sale.clientDoc}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="font-medium text-gray-800 block">{sale.product}</span>
                    <span className="text-[10px] text-gray-400">Cant: {sale.quantity} × S/ {sale.unitPrice.toFixed(2)}</span>
                  </td>
                  <td className="p-3 text-right font-mono text-gray-500">S/ {sale.subtotal.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono text-gray-500">S/ {sale.igv.toFixed(2)}</td>
                  <td className="p-3 text-right font-mono font-bold text-gray-900">
                    S/ {sale.total.toFixed(2)}
                  </td>
                  <td className="p-3 text-center">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold tracking-wide bg-emerald-100 text-emerald-850 border border-emerald-150 uppercase">
                      ACEPTADO (CDR)
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
