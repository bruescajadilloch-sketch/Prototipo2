import { motion } from "motion/react";
import { TrendingUp, FileText, Landmark, BadgePercent } from "lucide-react";
import { RealtimeStats } from "../types";

interface StatsSummaryProps {
  stats: RealtimeStats;
}

export default function StatsSummary({ stats }: StatsSummaryProps) {
  const formattedRevenue = `S/ ${stats.totalRevenue.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const formattedIgv = `S/ ${stats.totalIgv.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const formattedSubtotal = `S/ ${stats.totalSubtotal.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* 1. Total Ventas (PEN) */}
      <motion.div
        id="stat-revenue"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.0 }}
        className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between"
      >
        <div>
          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mb-1 font-sans">Total Ventas (PEN)</p>
          <h2 className="text-2xl font-bold text-slate-900 font-sans">{formattedRevenue}</h2>
        </div>
        <p className="text-xs text-emerald-600 font-semibold mt-1 font-sans">+12.5% vs mes anterior</p>
      </motion.div>

      {/* 2. Impuestos IGV (18%) */}
      <motion.div
        id="stat-igv"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.08 }}
        className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between"
      >
        <div>
          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mb-1 font-sans">Impuestos IGV (18%)</p>
          <h2 className="text-2xl font-bold text-slate-900 font-sans">{formattedIgv}</h2>
        </div>
        <p className="text-xs text-slate-400 mt-1 font-sans">Automático SUNAT SEE</p>
      </motion.div>

      {/* 3. Tickets Emitidos */}
      <motion.div
        id="stat-count"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.16 }}
        className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between"
      >
        <div>
          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mb-1 font-sans">Tickets Emitidos</p>
          <h2 className="text-2xl font-bold text-slate-900 font-sans">{stats.salesCount}</h2>
        </div>
        <p className="text-xs text-slate-400 mt-1 font-sans">Cálculo en tiempo real</p>
      </motion.div>

      {/* 4. Highlighted Base Imponible (using the blue design mockup style) */}
      <motion.div
        id="stat-subtotal"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.24 }}
        className="bg-blue-600 p-4 rounded-xl border border-blue-700 shadow-sm text-white flex flex-col justify-between"
      >
        <div>
          <p className="text-[10px] text-blue-100 uppercase font-bold tracking-widest mb-1 font-sans">Base Imponible (Subtotal)</p>
          <h2 className="text-2xl font-bold font-sans text-white">{formattedSubtotal}</h2>
        </div>
        <p className="text-xs text-blue-200 mt-1 font-sans">Top Performance Sede</p>
      </motion.div>
    </div>
  );
}
