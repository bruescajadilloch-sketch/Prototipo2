import { useMemo } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { motion } from "motion/react";
import { Building, ShoppingBag, Clock, BarChart3, PieChartIcon } from "lucide-react";
import { Sale, SalesByStore, SalesByProduct, SalesByHour } from "../types";

interface DashboardChartsProps {
  sales: Sale[];
}

const COLORS = ["#059669", "#2563eb", "#d97706", "#4f46e5", "#7c3aed", "#db2777"];

export default function DashboardCharts({ sales }: DashboardChartsProps) {
  // 1. Process Sales by Store
  const salesByStoreData = useMemo<SalesByStore[]>(() => {
    const storeMap: Record<string, { total: number; count: number }> = {};
    sales.forEach((s) => {
      if (!storeMap[s.store]) {
        storeMap[s.store] = { total: 0, count: 0 };
      }
      storeMap[s.store].total += s.total;
      storeMap[s.store].count += 1;
    });

    return Object.keys(storeMap).map((store) => ({
      store,
      total: Number(storeMap[store].total.toFixed(2)),
      count: storeMap[store].count,
    }));
  }, [sales]);

  // 2. Process Sales by Product
  const salesByProductData = useMemo<SalesByProduct[]>(() => {
    const productMap: Record<string, { total: number; quantity: number }> = {};
    sales.forEach((s) => {
      if (!productMap[s.product]) {
        productMap[s.product] = { total: 0, quantity: 0 };
      }
      productMap[s.product].total += s.total;
      productMap[s.product].quantity += s.quantity;
    });

    return Object.keys(productMap)
      .map((product) => ({
        product,
        total: Number(productMap[product].total.toFixed(2)),
        quantity: productMap[product].quantity,
      }))
      .sort((a, b) => b.total - a.total); // Sorted descending
  }, [sales]);

  // 3. Process Sales by Hour
  const salesByHourData = useMemo<SalesByHour[]>(() => {
    const hourMap: Record<number, number> = {};
    
    // Initialize standard hours to ensure clean trend line
    for (let h = 8; h <= 23; h++) {
      hourMap[h] = 0;
    }

    sales.forEach((s) => {
      const h = s.hour;
      if (hourMap[h] !== undefined) {
        hourMap[h] += s.total;
      } else {
        hourMap[h] = s.total;
      }
    });

    return Object.keys(hourMap)
      .map((hr) => {
        const hNum = parseInt(hr, 10);
        return {
          hourString: `${String(hNum).padStart(2, "0")}:00`,
          hour: hNum,
          total: Number(hourMap[hNum].toFixed(2)),
        };
      })
      .sort((a, b) => a.hour - b.hour);
  }, [sales]);

  // Total store list for labels
  const totalStores = salesByStoreData.length;
  // Total products list for labels
  const totalProducts = salesByProductData.length;

  // Custom tooltips
  const formatSolesTooltip = (value: any) => {
    return [`S/ ${Number(value).toFixed(2)}`, "Ventas Totales"];
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* CHART 1: Ventas por Local */}
        <motion.div
          id="chart-store"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between mb-4 border-b border-gray-50 pb-3">
            <div className="flex items-center space-x-2">
              <Building className="w-5 h-5 text-emerald-650" />
              <h4 className="font-semibold text-gray-800">Ventas por Local / Sucursal</h4>
            </div>
            <span className="text-[11px] font-mono text-gray-400 bg-gray-50 px-2.5 py-1 rounded-md">
              {totalStores} {totalStores === 1 ? "Local" : "Locales"}
            </span>
          </div>

          <div className="h-64">
            {salesByStoreData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-gray-450 text-sm">
                Sin datos de ventas por local
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesByStoreData} margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="store" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis
                    tickFormatter={(v) => `S/ ${v}`}
                    tick={{ fill: "#64748b", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    formatter={formatSolesTooltip}
                    cursor={{ fill: "#f8fafc" }}
                    contentStyle={{ borderRadius: "12px", border: "1px solid #f1f5f9", boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.05)" }}
                  />
                  <Bar dataKey="total" radius={[8, 8, 0, 0]} maxBarSize={45}>
                    {salesByStoreData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </motion.div>

        {/* CHART 2: Ventas por Producto */}
        <motion.div
          id="chart-product"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm"
        >
          <div className="flex items-center justify-between mb-4 border-b border-gray-50 pb-3">
            <div className="flex items-center space-x-2">
              <ShoppingBag className="w-5 h-5 text-blue-650" />
              <h4 className="font-semibold text-gray-800">Ventas por Producto</h4>
            </div>
            <span className="text-[11px] font-mono text-gray-400 bg-gray-50 px-2.5 py-1 rounded-md">
              {totalProducts} Productos
            </span>
          </div>

          <div className="h-64 flex flex-col sm:flex-row items-center justify-between gap-4">
            {salesByProductData.length === 0 ? (
              <div className="h-full w-full flex items-center justify-center text-gray-400 text-sm">
                Sin datos de productos
              </div>
            ) : (
              <>
                <div className="w-full sm:w-1/2 h-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={salesByProductData}
                        dataKey="total"
                        nameKey="product"
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={4}
                      >
                        {salesByProductData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(v) => `S/ ${Number(v).toFixed(2)}`}
                        contentStyle={{ borderRadius: "12px", border: "1px solid #f1f5f9", fontSize: 11 }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Legend list panel */}
                <div className="w-full sm:w-1/2 max-h-full overflow-y-auto space-y-1.5 text-xs">
                  {salesByProductData.slice(0, 6).map((item, idx) => (
                    <div key={item.product} className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                      <div className="flex items-center space-x-2 truncate pr-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                        />
                        <span className="font-medium text-gray-700 truncate max-w-[130px]" title={item.product}>
                          {item.product}
                        </span>
                      </div>
                      <span className="font-mono font-bold text-gray-800 flex-shrink-0">
                        S/ {item.total.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>

      {/* CHART 3: Tendencia de Ventas por Hora */}
      <motion.div
        id="chart-hour"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm"
      >
        <div className="flex items-center justify-between mb-4 border-b border-gray-50 pb-3">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-amber-650" />
            <h4 className="font-semibold text-gray-800">Curva de Emisión de Ventas por Hora (SEE SUNAT)</h4>
          </div>
          <p className="text-xs text-slate-500 font-sans">
            Muestra el flujo comercial durante la jornada de operaciones
          </p>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={salesByHourData} margin={{ top: 10, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="hourString" tick={{ fill: "#64748b", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis
                tickFormatter={(v) => `S/ ${v}`}
                tick={{ fill: "#64748b", fontSize: 10 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                formatter={(v) => [`S/ ${Number(v).toFixed(2)}`, "Ingreso Acumulado"]}
                contentStyle={{ borderRadius: "12px", border: "1px solid #f1f5f9", boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.05)" }}
              />
              <Line
                type="monotone"
                dataKey="total"
                stroke="#d97706"
                strokeWidth={3}
                dot={{ r: 4, strokeWidth: 1 }}
                activeDot={{ r: 6, strokeWidth: 0 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
}
