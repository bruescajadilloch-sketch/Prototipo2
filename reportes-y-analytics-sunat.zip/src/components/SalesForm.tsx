import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  User, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  HelpCircle, 
  Search, 
  Sparkles,
  RefreshCw,
  ShoppingBag,
  Building
} from "lucide-react";
import { ClientType, DocType, Sale } from "../types";
import { 
  validateRUC, 
  validateDNI, 
  calculateTaxSplit, 
  queryRucoDniAPI, 
  generateInvoiceNumber 
} from "../lib/sunatUtils";
import { MOCK_PRODUCTS, MOCK_STORES } from "../data/mockSales";

interface SalesFormProps {
  onAddSale: (sale: Sale) => Promise<void>;
  lastInvoiceNumber: number;
}

export default function SalesForm({ onAddSale, lastInvoiceNumber }: SalesFormProps) {
  // Form States
  const [store, setStore] = useState(MOCK_STORES[0]);
  const [selectedProduct, setSelectedProduct] = useState(MOCK_PRODUCTS[0].name);
  const [quantity, setQuantity] = useState<number>(1);
  const [unitPrice, setUnitPrice] = useState<number>(MOCK_PRODUCTS[0].price);
  const [pricesIncludeIgv, setPricesIncludeIgv] = useState<boolean>(true);
  
  const [clientType, setClientType] = useState<ClientType>("DNI");
  const [clientDoc, setClientDoc] = useState<string>("");
  const [clientName, setClientName] = useState<string>("");
  const [docType, setDocType] = useState<DocType>("Boleta");

  // Auxiliary Validation states
  const [docFeedback, setDocFeedback] = useState<{ isValid: boolean; message: string; subType?: string } | null>(null);
  const [isApiLoading, setIsApiLoading] = useState<boolean>(false);
  const [showReceiptPreview, setShowReceiptPreview] = useState<boolean>(false);
  const [lastSubmittedSale, setLastSubmittedSale] = useState<Sale | null>(null);

  // Sync: Change unitPrice when product modifies
  useEffect(() => {
    const prod = MOCK_PRODUCTS.find(p => p.name === selectedProduct);
    if (prod) {
      setUnitPrice(prod.price);
    }
  }, [selectedProduct]);

  // Sync: DNI only allows Boleta in SUNAT Perù
  useEffect(() => {
    if (clientType === "DNI") {
      setDocType("Boleta");
    }
  }, [clientType]);

  // Validate document input on change
  useEffect(() => {
    if (clientDoc.trim() === "") {
      setDocFeedback(null);
      setClientName("");
      return;
    }

    if (clientType === "DNI") {
      const res = validateDNI(clientDoc);
      if (res.isValid) {
        setDocFeedback({ isValid: true, message: res.message });
        const nameQuery = queryRucoDniAPI(clientDoc, "DNI");
        setClientName(nameQuery);
      } else {
        setDocFeedback({ isValid: false, message: res.message });
        setClientName("");
      }
    } else {
      const res = validateRUC(clientDoc);
      setDocFeedback({ 
        isValid: res.isValid, 
        message: res.message, 
        subType: res.subType 
      });
      if (res.isValid) {
        const nameQuery = queryRucoDniAPI(clientDoc, "RUC");
        setClientName(nameQuery);
      } else {
        setClientName("");
      }
    }
  }, [clientDoc, clientType]);

  // Tax split calculations
  const { subtotal, igv, total } = calculateTaxSplit(unitPrice, quantity, pricesIncludeIgv);

  // Trigger simulated API consultation
  const triggerConsultation = () => {
    if (!clientDoc) return;
    setIsApiLoading(true);
    setTimeout(() => {
      setIsApiLoading(false);
      if (clientType === "DNI") {
        const res = validateDNI(clientDoc);
        if (res.isValid) {
          setClientName(queryRucoDniAPI(clientDoc, "DNI"));
        }
      } else {
        const res = validateRUC(clientDoc);
        if (res.isValid) {
          setClientName(queryRucoDniAPI(clientDoc, "RUC"));
        }
      }
    }, 800);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Secondary rigorous checks
    if (clientType === "DNI" && clientDoc.length !== 8) {
      alert("El DNI ingresable de SUNAT debe tener 8 dígitos.");
      return;
    }
    if (clientType === "RUC" && clientDoc.length !== 11) {
      alert("El número de RUC de SUNAT debe tener 11 dígitos.");
      return;
    }
    if (!clientName.trim()) {
      alert("Ingrese o consulte un DNI/RUC para asignar un Titular o Razón Social.");
      return;
    }

    const generatedNumber = generateInvoiceNumber(docType, lastInvoiceNumber + 1);

    const newSale: Sale = {
      store,
      product: selectedProduct,
      quantity,
      unitPrice,
      subtotal,
      igv,
      total,
      timestamp: new Date().toISOString(),
      hour: new Date().getHours(),
      clientType,
      clientDoc,
      clientName,
      docType,
      docNumber: generatedNumber
    };

    try {
      await onAddSale(newSale);
      setLastSubmittedSale(newSale);
      setShowReceiptPreview(true);
      
      // Reset document states for safety
      setClientDoc("");
      setClientName("");
      setQuantity(1);
    } catch (err) {
      console.error("Failed to commit standard sale:", err);
    }
  };

  // Border feedback classes based on document validation state
  const getDocBorderClass = () => {
    if (!clientDoc) return "border-slate-200 focus:border-blue-500 focus:ring-blue-100";
    if (docFeedback?.isValid) return "border-emerald-400 focus:border-emerald-500 focus:ring-emerald-100 bg-emerald-50/10";
    // If length is partially there but not correct size, give Warning styling
    const requiredLength = clientType === "DNI" ? 8 : 11;
    if (clientDoc.length < requiredLength) {
      return "border-amber-300 focus:border-amber-400 focus:ring-amber-100 bg-amber-50/5";
    }
    return "border-red-400 focus:border-red-500 focus:ring-red-100 bg-red-50/5";
  };

  return (
    <div className="space-y-6">
      {/* Interactive Sunat Billing Form */}
      <motion.div
        id="sales-form-card"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-white border border-slate-200 rounded-xl shadow-sm p-5 lg:p-6"
      >
        <div className="flex items-center space-x-3 mb-5 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-800 leading-tight">Emisor de Comprobantes SEE</h3>
            <p className="text-xs text-slate-500">Sistema Certificado SUNAT - Cálculo de IGV (18%)</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* SUCURSAL & PRODUCT */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1.5 flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-slate-400" /> Sucursal / Local
              </label>
              <select
                value={store}
                onChange={(e) => setStore(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all text-slate-700"
              >
                {MOCK_STORES.map(st => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1.5 flex items-center gap-1">
                <ShoppingBag className="w-3.5 h-3.5 text-slate-400" /> Producto Gastronómico
              </label>
              <select
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all text-slate-700"
              >
                {MOCK_PRODUCTS.map(prd => (
                  <option key={prd.name} value={prd.name}>{prd.name} (S/ {prd.price.toFixed(2)})</option>
                ))}
              </select>
            </div>
          </div>

          {/* QUANTITY & UNIT PRICE AND SWITCH */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1.5">Cantidad</label>
              <input
                type="number"
                min="1"
                max="1000"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-500 transition-all text-slate-700"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-1.5">P. U. Unitario (S/)</label>
              <input
                type="number"
                step="0.01"
                min="0.1"
                value={unitPrice}
                onChange={(e) => setUnitPrice(Number(e.target.value))}
                className="w-full text-sm border border-slate-200 rounded-lg p-2.5 bg-slate-50/50 focus:bg-white focus:outline-none focus:border-blue-500 transition-all font-mono font-medium text-slate-700"
                required
              />
            </div>

            {/* Price Include IGV Switch */}
            <div className="flex items-center justify-between p-2.5 border border-gray-150 rounded-xl bg-slate-50/50">
              <span className="text-xs text-gray-600 font-medium">Precios con IGV</span>
              <button
                type="button"
                onClick={() => setPricesIncludeIgv(!pricesIncludeIgv)}
                className={`w-11 h-6 rounded-full transition-colors relative flex items-center px-1 ${
                  pricesIncludeIgv ? "bg-emerald-505" : "bg-gray-300"
                }`}
                style={{ backgroundColor: pricesIncludeIgv ? "#059669" : undefined }}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    pricesIncludeIgv ? "translate-x-5" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
          </div>

          <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex md:flex-row flex-col justify-between items-center text-xs text-slate-600 gap-4">
            <span className="font-medium text-slate-700">Fórmula de Tributación SUNAT:</span>
            <div className="flex gap-4 font-mono">
              <span className="bg-white border rounded px-2.5 py-1">
                Base: S/ {subtotal.toFixed(2)}
              </span>
              <span className="bg-white border rounded px-2.5 py-1">
                IGV (18%): S/ {igv.toFixed(2)}
              </span>
              <span className="bg-emerald-50 text-emerald-750 font-bold border border-emerald-100 rounded px-2.5 py-1">
                Total: S/ {total.toFixed(2)}
              </span>
            </div>
          </div>

          {/* SUNAT CLIENT DOCUMENT FORM SECTION */}
          <div className="pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                Datos del Adquirente (Cliente SUNAT)
              </label>
              
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setClientType("DNI");
                    setClientDoc("");
                    setClientName("");
                  }}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                    clientType === "DNI" 
                      ? "bg-slate-900 text-white shadow-sm" 
                      : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                  }`}
                >
                  DNI (Personas)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setClientType("RUC");
                    setClientDoc("");
                    setClientName("");
                  }}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                    clientType === "RUC" 
                      ? "bg-slate-900 text-white shadow-sm" 
                      : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                  }`}
                >
                  RUC (Empresas)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-start">
              {/* Document input */}
              <div className="md:col-span-4 relative group">
                <input
                  type="text"
                  maxLength={clientType === "DNI" ? 8 : 11}
                  placeholder={clientType === "DNI" ? "Ejem: 45893214" : "Ejem: 20100456781"}
                  value={clientDoc}
                  onChange={(e) => setClientDoc(e.target.value.replace(/\D/g, ""))}
                  className={`w-full text-sm border rounded-lg p-2.5 focus:outline-none focus:ring-1 transition-all font-mono text-slate-700 bg-slate-50/20 ${getDocBorderClass()}`}
                  required
                />
                
                {/* Character counters absolute top right */}
                <div className="absolute right-2.5 top-3.5 flex items-center space-x-1.5 text-[9px] text-slate-400 font-mono">
                  <span>
                    {clientDoc.length}/{clientType === "DNI" ? 8 : 11} dig
                  </span>
                </div>
              </div>

              {/* Razón Social/Nombre */}
              <div className="md:col-span-5 relative">
                <input
                  type="text"
                  placeholder={clientType === "DNI" ? "Nombre completo del titular" : "Razón Social de la empresa"}
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full text-sm border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-slate-50/20 text-slate-700"
                  required
                />
                <User className="w-4 h-4 text-slate-400 absolute right-3 top-3.5" />
              </div>

              {/* API consult button */}
              <button
                type="button"
                onClick={triggerConsultation}
                disabled={isApiLoading || clientDoc.length < (clientType === "DNI" ? 8 : 11)}
                className="md:col-span-3 w-full bg-blue-600 border border-blue-700 text-white hover:bg-blue-700 disabled:bg-slate-100 disabled:text-slate-400 disabled:border-slate-200 transition-all rounded-lg p-2.5 text-xs font-bold flex items-center justify-center space-x-1.5 h-[41px] cursor-pointer"
              >
                {isApiLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <>
                    <Search className="w-3.5 h-3.5" />
                    <span>Consulta SUNAT</span>
                  </>
                )}
              </button>
            </div>

            {/* Visual Feedback Alerts */}
            <AnimatePresence mode="wait">
              {docFeedback && (
                <motion.div
                  key={clientDoc}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-2 text-xs"
                >
                  <div className={`p-2.5 rounded-lg flex items-start space-x-2 border ${
                    docFeedback.isValid 
                      ? "bg-emerald-50 border-emerald-150 text-emerald-800" 
                      : "bg-amber-50 border-amber-150 text-amber-800"
                  }`}>
                    {docFeedback.isValid ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-bold font-sans">
                        {docFeedback.isValid ? "Validación Exitosa: " : "Alerta de Estructura: "}
                      </span>
                      <span>{docFeedback.message}</span>
                      {docFeedback.subType && (
                        <p className="font-mono text-[9px] mt-0.5 text-emerald-700 bg-emerald-100 inline-block px-1.5 py-0.5 rounded font-bold">
                          Contribuyente: {docFeedback.subType}
                        </p>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* COMPROBANTE SELECTOR (BOLETA vs FACTURA) */}
          <div className="pt-3 border-t border-slate-100">
            <label className="block text-[10px] uppercase font-bold text-slate-500 tracking-wider mb-2">
              Tipo de Comprobante electrónico a emitir
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDocType("Boleta")}
                className={`p-3 border rounded-xl flex flex-col items-start transition-all relative overflow-hidden ${
                  docType === "Boleta"
                    ? "border-emerald-600 bg-emerald-50/25 text-emerald-900 ring-2 ring-emerald-600/20"
                    : "border-gray-200 hover:bg-slate-50 text-gray-600"
                }`}
              >
                <span className="text-xs font-bold">BOLETA DE VENTA</span>
                <span className="text-[10px] text-gray-450 mt-1">Sugerido para DNI o Consumidor Final</span>
                <span className="text-[9px] font-mono text-emerald-600 mt-0.5 bg-emerald-50 border border-emerald-100 px-1 rounded">
                  Serie B001
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (clientType === "DNI") {
                    alert("Alerta SUNAT: No se puede emitir Factura a clientes con DNI. Debe ingresar un RUC.");
                    setClientType("RUC");
                    setClientDoc("");
                    setClientName("");
                  }
                  setDocType("Factura");
                }}
                className={`p-3 border rounded-xl flex flex-col items-start transition-all relative overflow-hidden ${
                  docType === "Factura"
                    ? "border-emerald-600 bg-emerald-50/25 text-emerald-900 ring-2 ring-emerald-600/20"
                    : "border-gray-200 hover:bg-slate-50 text-gray-600"
                }`}
              >
                <span className="text-xs font-bold">FACTURA ELECTRÓNICA</span>
                <span className="text-[10px] text-gray-450 mt-1">Mandatorio para RUC con crédito fiscal</span>
                <span className="text-[9px] font-mono text-emerald-600 mt-0.5 bg-emerald-50 border border-emerald-100 px-1 rounded">
                  Serie F001
                </span>
              </button>
            </div>
          </div>

          {/* EMIT COMPROBANTE */}
          <button
            type="submit"
            disabled={!clientDoc || !clientName || (docFeedback && !docFeedback.isValid) || false}
            className="w-full bg-slate-900 border border-slate-950 hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-400 disabled:border-slate-200 text-white font-bold transition-all rounded-lg py-3 px-4 text-xs tracking-widest uppercase flex items-center justify-center space-x-2 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-blue-400" />
            <span>Emitir Comprobante</span>
          </button>
        </form>
      </motion.div>

      {/* COMPROBANTE EMITIDO PREVIEW MODAL/CARD */}
      <AnimatePresence>
        {showReceiptPreview && lastSubmittedSale && (
          <motion.div
            id="invoice-receipt-popup"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-slate-900 text-white border border-slate-950 rounded-2xl p-5 shadow-lg space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-mono tracking-wider text-emerald-400 font-bold uppercase">
                  SUNAT SEE RECIBIDO CDR: OK
                </span>
              </div>
              <button 
                onClick={() => setShowReceiptPreview(false)}
                className="text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded-lg"
              >
                Cerrar Recibo
              </button>
            </div>

            <div className="font-mono text-xs space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto">
              <div className="text-center border-b border-dashed border-slate-800 pb-2">
                <p className="font-bold text-sm">INVERSIONES GASTRONOMICAS SAC</p>
                <p className="text-[10px] text-slate-450">RUC: 20601234567</p>
                <p className="text-[10px] text-slate-450">Av. Benavides 1245, Miraflores, Lima</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div>
                  <span className="text-slate-500">Comprobante:</span>
                  <p className="font-bold text-white">{lastSubmittedSale.docType} Electrónica</p>
                </div>
                <div>
                  <span className="text-slate-500">Serie Núm:</span>
                  <p className="font-bold text-white">{lastSubmittedSale.docNumber}</p>
                </div>
                <div>
                  <span className="text-slate-500">Fecha Emisión:</span>
                  <p className="text-white">{new Date(lastSubmittedSale.timestamp).toLocaleString("es-PE")}</p>
                </div>
                <div>
                  <span className="text-slate-500">Local de Venta:</span>
                  <p className="text-white">{lastSubmittedSale.store}</p>
                </div>
              </div>

              <div className="border-t border-b border-dashed border-slate-800 py-2 my-2 text-[11px]">
                <div className="grid grid-cols-12 gap-1 text-slate-500 font-bold mb-1">
                  <span className="col-span-6">Concepto</span>
                  <span className="col-span-2 text-center">Cant</span>
                  <span className="col-span-4 text-right">Total</span>
                </div>
                <div className="grid grid-cols-12 gap-1 text-white">
                  <span className="col-span-6 truncate" title={lastSubmittedSale.product}>{lastSubmittedSale.product}</span>
                  <span className="col-span-2 text-center">{lastSubmittedSale.quantity}</span>
                  <span className="col-span-4 text-right font-bold">S/ {lastSubmittedSale.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-1 text-right text-[11px]">
                <div>
                  <span className="text-slate-500 mr-2">Operación Gravada (Subtotal):</span>
                  <span className="text-white">S/ {lastSubmittedSale.subtotal.toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-slate-500 mr-2">Tasa IGV (18.00%):</span>
                  <span className="text-white">S/ {lastSubmittedSale.igv.toFixed(2)}</span>
                </div>
                <div className="border-t border-slate-800 pt-1 text-xs font-bold">
                  <span className="text-emerald-400 mr-2">Importe Total:</span>
                  <span className="text-emerald-400">S/ {lastSubmittedSale.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-dashed border-slate-800 text-[10px]">
                <p className="truncate"><span className="text-slate-500">Adquirente:</span> {lastSubmittedSale.clientName}</p>
                <p><span className="text-slate-500">{lastSubmittedSale.clientType}:</span> {lastSubmittedSale.clientDoc}</p>
              </div>

              <div className="text-center pt-2 text-[8px] text-slate-400">
                <p>Representación impresa autorizada mediante Resolución de SUNAT Nº 034-2020.</p>
                <p className="font-bold text-emerald-500/80 mt-1">Hash PDF-XML: {Math.random().toString(16).slice(2, 10).toUpperCase()}-SUNAT-SEE</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
