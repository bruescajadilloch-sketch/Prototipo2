/**
 * Unified type definitions for the SUNAT Sales & Analytics dashboard
 */

export type ClientType = "DNI" | "RUC";
export type DocType = "Boleta" | "Factura";

export interface Sale {
  id?: string;
  store: string;       // Sede / Local (e.g. Sede Miraflores, Sede San Isidro)
  product: string;     // Producto vendido
  quantity: number;    // Cantidad vendida
  unitPrice: number;   // Precio unitario con IGV incluido
  subtotal: number;    // Base Imponible (Total / 1.18)
  igv: number;         // Impuesto General a las Ventas (18% de subtotal)
  total: number;       // Total pagado (Subtotal + IGV)
  timestamp: string;   // Fecha de venta ISO string
  hour: number;        // Hora del día (0-23)
  clientType: ClientType; // Tipo de Doc cliente
  clientDoc: string;   // Número de documento (8 digitos DNI, 11 digitos RUC)
  clientName: string;  // Nombre o Razón Social del Cliente
  docType: DocType;    // Tipo de comprobante (Boleta o Factura)
  docNumber: string;   // Nº de comprobante (ej. F001-00000123 / B001-00000123)
}

export interface SalesByStore {
  store: string;
  total: number;
  count: number;
}

export interface SalesByProduct {
  product: string;
  total: number;
  quantity: number;
}

export interface SalesByHour {
  hourString: string;
  hour: number;
  total: number;
}

export interface RealtimeStats {
  totalRevenue: number;
  totalIgv: number;
  totalSubtotal: number;
  salesCount: number;
}
