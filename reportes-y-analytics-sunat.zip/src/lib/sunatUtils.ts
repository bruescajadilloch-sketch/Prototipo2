/**
 * SUNAT standards & validation utilities for Peru
 */

/**
 * Validates a Peruvian RUC using the official Modulo 11 check digit algorithm.
 * A Peruvian RUC has 11 digits:
 * - Starts with 10, 15, 17 or 20.
 * - Weights for positions 1 to 10 are: 5, 4, 3, 2, 7, 6, 5, 4, 3, 2
 */
export function validateRUC(ruc: string): { isValid: boolean; message: string; subType?: string } {
  // Check length and digits
  if (!/^\d{11}$/.test(ruc)) {
    return { isValid: false, message: "Debe contener exactamente 11 dígitos numéricos." };
  }

  const prefix = ruc.slice(0, 2);
  const validPrefixes = ["10", "15", "17", "20"];
  if (!validPrefixes.includes(prefix)) {
    return { isValid: false, message: "Prefix no válido. Debe empezar con 10, 15, 17 o 20." };
  }

  const weights = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(ruc.charAt(i), 10) * weights[i];
  }

  const mod = sum % 11;
  let rest = 11 - mod;
  if (rest === 10) rest = 0;
  if (rest === 11) rest = 1;

  const lastDigit = parseInt(ruc.charAt(10), 10);
  const isValid = rest === lastDigit;

  let subType = "Persona Jurídica";
  if (prefix === "10") subType = "Persona Natural con Negocio";
  else if (prefix === "15") subType = "Persona Natural Autogestionada";
  else if (prefix === "17") subType = "Persona No Domiciliada";

  if (!isValid) {
    return { 
      isValid: false, 
      message: "Algoritmo de control SUNAT fallido (RUC no existe o dígito verificador inválido).",
      subType
    };
  }

  return { 
    isValid: true, 
    message: `RUC Válido (${subType})`,
    subType
  };
}

/**
 * Validates a Peruvian DNI (8 numeric digits)
 */
export function validateDNI(dni: string): { isValid: boolean; message: string } {
  if (!/^\d{8}$/.test(dni)) {
    return { isValid: false, message: "Debe contener exactamente 8 dígitos numéricos." };
  }
  return { isValid: true, message: "DNI Válido" };
}

/**
 * Calculates Subtotal (Base Imponible), IGV (18%), and Total from Price and Quantity.
 * standard consumers see inclusive prices.
 * - Total = unitPrice * quantity
 * - Subtotal = Total / 1.18
 * - IGV = Total - Subtotal
 */
export function calculateTaxSplit(unitPrice: number, quantity: number, pricesIncludeIgv: boolean = true) {
  const totalRaw = unitPrice * quantity;
  let total = 0;
  let subtotal = 0;
  let igv = 0;

  if (pricesIncludeIgv) {
    total = Number(totalRaw.toFixed(2));
    subtotal = Number((total / 1.18).toFixed(2));
    igv = Number((total - subtotal).toFixed(2));
  } else {
    subtotal = Number(totalRaw.toFixed(2));
    igv = Number((subtotal * 0.18).toFixed(2));
    total = Number((subtotal + igv).toFixed(2));
  }

  return { subtotal, igv, total };
}

/**
 * Generates a randomized SUNAT-style Invoice Number or Ticket Number.
 * Series start with:
 * - 'F001-' for Facturas
 * - 'B001-' for Boletas
 */
export function generateInvoiceNumber(docType: "Boleta" | "Factura", lastNumber: number): string {
  const prefix = docType === "Factura" ? "F001" : "B001";
  const sequential = String(lastNumber).padStart(8, "0");
  return `${prefix}-${sequential}`;
}

/**
 * Custom Peruvian name generator/fetcher tool simulation
 * In real-world Peru, developers use APIs from SUNAT or RENIEC.
 * Inside our application, we can simulate an official API query returning
 * corresponding business or citizen details for visual delight!
 */
export function queryRucoDniAPI(doc: string, type: "DNI" | "RUC"): string {
  // A clean dictionary of simulated SUNAT/RENIEC records for standard test inputs
  const mockDatabase: Record<string, string> = {
    "20100456781": "SOPORTE TECNICO PERU SAC",
    "20551122334": "DISTRIBUIDORA DE ALIMENTOS ANDINOS EIRL",
    "20448833991": "SERVICIOS LOGISTICOS PERU S.A.C.",
    "20601234567": "INVERSIONES GASTRONOMICAS EL DORADO S.A.",
    "10458932145": "GÓMEZ HUAMÁN, ADRIÁN ENRIQUE",
    "45893214": "Juan Alberto Pérez Mendoza",
    "72145896": "María Alejandra Ramos Ruiz",
    "09685741": "Carlos Eduardo Gómez Vega",
    "41253698": "Sofía Lorena Castro Díaz",
    "44229988": "David Renato Espinoza Prado",
    "10748596": "Gabriela Lucía Torres Pardo",
    "32985614": "Fernando José Medina Ríos",
    "08776655": "Elena Milagros Ortiz Rojas"
  };

  if (mockDatabase[doc]) {
    return mockDatabase[doc];
  }

  // Generate a plausible Peruvian name or Business name if not matching standard mock
  if (type === "RUC") {
    // Check checksum subtype
    const res = validateRUC(doc);
    if (!res.isValid) return "";
    const randomSuffixes = ["IMPORTACIONES S.A.C.", "CONSTRUCTORES E.I.R.L.", "SERVICIOS INTEGRALES PERU S.A.", "ALIMENTOS Y BEBIDAS S.A.C."];
    // Hash some digit parts to pick suffix
    const num = parseInt(doc.slice(2, 6)) || 0;
    const suffix = randomSuffixes[num % randomSuffixes.length];
    return `EMPRESA DE PRUEBA RUC ${doc.slice(2, 8)} ${suffix}`;
  } else {
    if (!/^\d{8}$/.test(doc)) return "";
    const names = ["Andrés", "Camila", "Javier", "Diana", "Renzo", "Patricia", "Hugo", "Fiorella", "Gonzalo", "Vanessa"];
    const lastnames1 = ["Quispe", "Flores", "Sánchez", "García", "Rodríguez", "Rojas", "Chávez", "Torres", "Díaz", "Ccahuana"];
    const lastnames2 = ["Alvarado", "Mamani", "Carranza", "Zegarra", "Castillo", "Guerrero", "Villanueva", "Vargas", "Nieto", "Huamán"];
    const dNum = parseInt(doc.slice(4, 8)) || 0;
    const n = names[dNum % names.length];
    const l1 = lastnames1[(dNum + 3) % lastnames1.length];
    const l2 = lastnames2[(dNum + 7) % lastnames2.length];
    return `${n} ${l1} ${l2}`;
  }
}
