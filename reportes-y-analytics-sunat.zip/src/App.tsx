import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  TrendingUp, 
  HelpCircle, 
  CheckCircle2, 
  CloudLightning, 
  CloudOff, 
  LogIn, 
  LogOut, 
  RefreshCw,
  Clock,
  PlusCircle,
  RotateCcw,
  Sparkles,
  Info
} from "lucide-react";

// Local imports
import { Sale, RealtimeStats } from "./types";
import { INITIAL_MOCK_SALES } from "./data/mockSales";
import { db, auth, googleProvider, isFirebasePlaceholder, handleFirestoreError, OperationType } from "./lib/firebase";
import firebaseConfig from "../firebase-applet-config.json";

// Components
import StatsSummary from "./components/StatsSummary";
import DashboardCharts from "./components/DashboardCharts";
import SalesForm from "./components/SalesForm";
import SalesHistoryList from "./components/SalesHistoryList";

// Firebase imports
import { collection, onSnapshot, addDoc } from "firebase/firestore";
import { onAuthStateChanged, signInWithPopup, signOut } from "firebase/auth";

export default function App() {
  const [sales, setSales] = useState<Sale[]>(() => {
    // Read from localStorage initially for Sandbox Mode Persistence!
    const saved = localStorage.getItem("sunat_sales_records");
    return saved ? JSON.parse(saved) : INITIAL_MOCK_SALES;
  });

  const [currUser, setCurrUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [isFirebaseSynced, setIsFirebaseSynced] = useState<boolean>(false);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);

  // Selected receipt configuration for receipt popup
  const [selectedReceipt, setSelectedReceipt] = useState<Sale | null>(null);

  // Sync state with localStorage if in sandbox (not logged into firebase)
  useEffect(() => {
    if (!currUser) {
      localStorage.setItem("sunat_sales_records", JSON.stringify(sales));
    }
  }, [sales, currUser]);

  // Firebase Auth and Firestore synchronization
  useEffect(() => {
    if (isFirebasePlaceholder || !db || !auth) {
      setAuthLoading(false);
      return;
    }

    setAuthLoading(true);
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setCurrUser(user);
      setAuthLoading(false);

      if (user) {
        // Connected: Sync with real firestore sales collection dynamically!
        const salesCollection = collection(db, "sales");
        
        const unsubscribeSnapshot = onSnapshot(
          salesCollection,
          (snapshot) => {
            const firestoreSales: Sale[] = [];
            snapshot.forEach((doc) => {
              const data = doc.data() as Omit<Sale, "id">;
              firestoreSales.push({ id: doc.id, ...data });
            });
            
            // If we have records in firestore, use those; otherwise seed them
            if (firestoreSales.length > 0) {
              setSales(firestoreSales);
            } else {
              // No records in firestore yet, seed Firestore with initial data!
              INITIAL_MOCK_SALES.forEach(async (item) => {
                try {
                  await addDoc(salesCollection, item);
                } catch (err) {
                  console.error("Error seeding initial files in cloud:", err);
                }
              });
            }
            setIsFirebaseSynced(true);
            setFirebaseError(null);
          },
          (error) => {
            console.error("Firestore read error callback executed:", error);
            setFirebaseError("Permisos insuficientes o base de datos offline. Operando en modo Local.");
            setIsFirebaseSynced(false);
            try {
              handleFirestoreError(error, OperationType.LIST, "sales");
            } catch (e) {
              // Handled and logged
            }
          }
        );

        return () => {
          unsubscribeSnapshot();
        };
      } else {
        setIsFirebaseSynced(false);
        // Fallback to local storage records when logged out
        const saved = localStorage.getItem("sunat_sales_records");
        setSales(saved ? JSON.parse(saved) : INITIAL_MOCK_SALES);
      }
    });

    return () => {
      unsubscribeAuth();
    };
  }, []);

  // Compute real-time KPI totals
  const stats = useMemo<RealtimeStats>(() => {
    let revenue = 0;
    let igvAmount = 0;
    let subtotalAmount = 0;

    sales.forEach((s) => {
      revenue += s.total;
      igvAmount += s.igv;
      subtotalAmount += s.subtotal;
    });

    return {
      totalRevenue: Number(revenue.toFixed(2)),
      totalIgv: Number(igvAmount.toFixed(2)),
      totalSubtotal: Number(subtotalAmount.toFixed(2)),
      salesCount: sales.length
    };
  }, [sales]);

  // Helper trigger to log in with Google
  const handleLogin = async () => {
    if (isFirebasePlaceholder || !auth || !googleProvider) {
      alert("Su configuración de Firebase aún está en modo de demostración. Active Firebase en AI Studio para iniciar sesión con credenciales reales.");
      return;
    }
    try {
      setAuthLoading(true);
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error("Sign in failed:", err);
      alert("Error en el inicio de sesión de Google.");
    } finally {
      setAuthLoading(false);
    }
  };

  // Helper trigger to logout
  const handleLogout = async () => {
    if (isFirebasePlaceholder || !auth) return;
    try {
      await signOut(auth);
      setCurrUser(null);
      setIsFirebaseSynced(false);
    } catch (err) {
      console.error("Sign out failed:", err);
    }
  };

  // Triggered when a new sale is created in form
  const handleAddSale = async (newSale: Sale) => {
    if (currUser && db && !isFirebasePlaceholder) {
      try {
        await addDoc(collection(db, "sales"), newSale);
        // State updates automatically via onSnapshot listener!
      } catch (error) {
        console.error("Error adding sale to Firestore:", error);
        setFirebaseError("Error de escritura de Firestore. Guardado localmente.");
        // Fallback local append
        setSales(prev => [newSale, ...prev]);
        try {
          handleFirestoreError(error, OperationType.CREATE, "sales");
        } catch (e) {
          // Handled and logged
        }
      }
    } else {
      // Sandbox mode: append directly to state
      setSales(prev => [newSale, ...prev]);
    }
  };

  // Generator of mock sales to fill dashboard instantly
  const handleSeedRandomSale = () => {
    const productsList = [
      { name: "Ceviche Carretillero", price: 48.00 },
      { name: "Lomo Saltado Criollo", price: 52.00 },
      { name: "Arroz con Mariscos", price: 45.00 },
      { name: "Pisco Sour Catedral", price: 32.00 },
      { name: "Chicha Morada (1L)", price: 18.00 }
    ];
    const storesList = ["Sede Miraflores", "Sede San Isidro", "Sede Surco"];
    const clientsList = [
      { type: "DNI" as const, doc: "45129329", name: "Esteban Quiroz Salas" },
      { type: "RUC" as const, doc: "20551122334", name: "DISTRIBUIDORA DE ALIMENTOS ANDINOS EIRL" },
      { type: "DNI" as const, doc: "10748596", name: "Gabriela Lucía Torres Pardo" },
      { type: "RUC" as const, doc: "20100456781", name: "SOPORTE TECNICO PERU SAC" },
      { type: "DNI" as const, doc: "44229988", name: "David Renato Espinoza Prado" }
    ];

    const randomProduct = productsList[Math.floor(Math.random() * productsList.length)];
    const randomStore = storesList[Math.floor(Math.random() * storesList.length)];
    const randomClient = clientsList[Math.floor(Math.random() * clientsList.length)];
    const qty = Math.floor(Math.random() * 3) + 1;
    
    // Tax splitting
    const totalRaw = randomProduct.price * qty;
    const sub = Number((totalRaw / 1.18).toFixed(2));
    const tx = Number((totalRaw - sub).toFixed(2));

    const isFactura = randomClient.type === "RUC" && Math.random() > 0.4;
    const docPrefix = isFactura ? "F001" : "B001";
    const randSeqNum = String(Math.floor(Math.random() * 900) + 100).padStart(8, "0");

    const newSale: Sale = {
      store: randomStore,
      product: randomProduct.name,
      quantity: qty,
      unitPrice: randomProduct.price,
      subtotal: sub,
      igv: tx,
      total: Number(totalRaw.toFixed(2)),
      timestamp: new Date().toISOString(),
      hour: new Date().getHours(),
      clientType: randomClient.type,
      clientDoc: randomClient.doc,
      clientName: randomClient.name,
      docType: isFactura ? "Factura" : "Boleta",
      docNumber: `${docPrefix}-${randSeqNum}`
    };

    handleAddSale(newSale);
  };

  // Reset/Clear metrics
  const handleResetMetrics = () => {
    if (window.confirm("¿Seguro que desea resetear la base de datos a los valores por defecto?")) {
      localStorage.removeItem("sunat_sales_records");
      setSales(INITIAL_MOCK_SALES);
    }
  };

  // Get next serial index to compute series sequential numbering
  const lastInvoiceIndex = useMemo(() => {
    return sales.length;
  }, [sales]);

  return (
    <div className="flex h-screen w-full bg-slate-50 font-sans overflow-hidden">
      {/* Left Sidebar */}
      <aside className="w-64 bg-slate-900 text-slate-300 md:flex flex-col border-r border-slate-800 hidden shrink-0">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-white shadow-md">S</div>
          <div>
            <h1 className="text-white font-bold leading-none tracking-tight">SISTEMA SEE</h1>
            <p className="text-[10px] text-slate-500 mt-1 uppercase font-semibold tracking-wider">Compliance SUNAT</p>
          </div>
        </div>
        <nav className="flex-1 py-4">
          <div className="px-6 py-3 bg-blue-600/10 text-blue-400 border-l-4 border-blue-500 flex items-center gap-3 cursor-default">
            <span className="text-sm font-medium">Dashboard Analítico</span>
          </div>
          <div className="px-6 py-3 hover:bg-slate-800/30 flex items-center gap-3 transition-colors opacity-50 cursor-not-allowed">
            <span className="text-sm">Comprobantes</span>
          </div>
          <div className="px-6 py-3 hover:bg-slate-800/30 flex items-center gap-3 transition-colors opacity-50 cursor-not-allowed">
            <span className="text-sm">Catálogo Productos</span>
          </div>
          <div className="px-6 py-3 hover:bg-slate-800/30 flex items-center gap-3 transition-colors opacity-50 cursor-not-allowed">
            <span className="text-sm">Gestión Locales</span>
          </div>
        </nav>
        <div className="p-6 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3 mb-2">
            <div className={`w-2.5 h-2.5 rounded-full ${isFirebaseSynced ? "bg-green-500 shadow-[0_0_8px_#22c55e]" : "bg-amber-500 shadow-[0_0_8px_#f59e0b]"} animate-pulse`}></div>
            <span className="text-[10px] uppercase font-bold text-slate-500">
              {isFirebasePlaceholder ? "Modo Sandbox" : isFirebaseSynced ? "Firebase Connected" : "Connecting Sync"}
            </span>
          </div>
          <p className="text-xs text-slate-400 truncate font-mono">
            {isFirebasePlaceholder ? "see-sunat-v2.local" : (firebaseConfig.projectId ? `${firebaseConfig.projectId}.app` : "connecting...")}
          </p>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-y-auto">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sm:px-8 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-sm hidden sm:inline">Módulo</span>
            <span className="text-slate-300 hidden sm:inline">/</span>
            <span className="text-slate-900 font-semibold text-sm sm:text-base">Reportes de Ventas & Analytics</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-3 py-1 bg-slate-100 rounded text-xs font-mono font-bold text-slate-600 border border-slate-200">
              IGV: 18.00%
            </div>
            
            {/* Status indicators for mobile / small screen only */}
            <div className="md:hidden">
              {isFirebasePlaceholder ? (
                <span className="inline-flex items-center px-2 py-1 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                  Sandbox
                </span>
              ) : isFirebaseSynced ? (
                <span className="inline-flex items-center px-2 py-1 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
                  Synced
                </span>
              ) : (
                <span className="inline-flex items-center px-2 py-1 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-100">
                  Local
                </span>
              )}
            </div>

            {/* Auth controllers or User Profile */}
            {!isFirebasePlaceholder && (
              <>
                {authLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-400" />
                ) : currUser ? (
                  <div className="flex items-center bg-slate-50 p-1 rounded-xl border border-slate-200 space-x-1.5">
                    {currUser.photoURL ? (
                      <img 
                        src={currUser.photoURL} 
                        alt="Profile" 
                        className="w-6 h-6 rounded-full border border-slate-300"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-600">U</div>
                    )}
                    <span className="text-xs font-medium max-w-[80px] truncate hidden sm:block text-slate-700">
                      {currUser.displayName || currUser.email}
                    </span>
                    <button
                      onClick={handleLogout}
                      title="Cerrar Sesión"
                      className="p-1 text-slate-400 hover:text-slate-600 transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleLogin}
                    className="bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white px-3 py-1.5 rounded-lg flex items-center space-x-1 transition-all shadow-sm"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Conectar</span>
                  </button>
                )}
              </>
            )}
          </div>
        </header>

        {/* FIREBASE SYNC ERROR NOTIFICATION BAR */}
        {firebaseError && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-800 py-2.5 px-6 shrink-0">
            <div className="text-xs font-medium flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Info className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>{firebaseError}</span>
              </div>
              <button 
                onClick={() => setFirebaseError(null)} 
                className="text-[10px] text-amber-600 font-bold bg-amber-100 hover:bg-amber-200 px-2 py-0.5 rounded"
              >
                Cerrar
              </button>
            </div>
          </div>
        )}

        {/* Content wrap section with standard scrollable behaviour */}
        <div className="p-6 flex flex-col gap-6">
          
          {/* Quick interactive parameters bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <div className="text-xs text-slate-500">
              <span className="font-bold text-slate-700">Comandos rápidos:</span> Genere transacciones para estresar los validadores o limpie la base de datos local.
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleSeedRandomSale}
                className="bg-blue-50 hover:bg-blue-105 hover:bg-blue-100 text-blue-700 font-bold text-xs px-3 py-1.5 rounded-lg flex items-center space-x-1 border border-blue-200 transition-all cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Venta Aleatoria</span>
              </button>
              <button
                onClick={handleResetMetrics}
                className="bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold text-xs px-3 py-1.5 rounded-lg flex items-center space-x-1 border border-slate-200 transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Resetear Base</span>
              </button>
            </div>
          </div>

          {/* Stats Cards Row */}
          <StatsSummary stats={stats} />

          {/* Form and Charts Area Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-5 col-auto">
              <SalesForm 
                onAddSale={handleAddSale} 
                lastInvoiceNumber={lastInvoiceIndex} 
              />
            </div>
            <div className="lg:col-span-7 col-auto">
              <DashboardCharts sales={sales} />
            </div>
          </div>

          {/* Recent Transacations Table list */}
          <SalesHistoryList 
            sales={sales} 
            onViewReceipt={(sale) => setSelectedReceipt(sale)} 
          />
        </div>
      </main>

      {/* INDEPENDENT POPUP DETAILED PRINT DIALOG */}
      <AnimatePresence>
        {selectedReceipt && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-950 text-white p-5 rounded-2xl w-full max-w-sm shadow-2xl relative"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
                <span className="font-mono text-[10px] text-emerald-400 font-bold">Impresora Fiscal Integrada</span>
                <button
                  type="button"
                  onClick={() => setSelectedReceipt(null)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg p-1.5 text-xs font-mono"
                >
                  Cerrar
                </button>
              </div>

              {/* Receipt printer shape */}
              <div className="font-mono text-xs bg-slate-950 p-4 rounded-xl space-y-3 shrink-0">
                <div className="text-center border-b border-dashed border-slate-700 pb-2">
                  <p className="font-bold text-sm tracking-tight uppercase">Sabor & Fuego</p>
                  <p className="text-[10px] text-slate-500">INVERSIONES GASTRONOMICAS S.A.C.</p>
                  <p className="text-[9px] text-slate-500">Av. Javier Prado Este 2450, San Isidro</p>
                </div>

                <div className="space-y-1 text-[11px]">
                  <p><span className="text-slate-500">Comprobante:</span> {selectedReceipt.docType}</p>
                  <p><span className="text-slate-500">Número:</span> {selectedReceipt.docNumber}</p>
                  <p><span className="text-slate-500">Emisión:</span> {new Date(selectedReceipt.timestamp).toLocaleString("es-PE")}</p>
                  <p><span className="text-slate-500">Dirección:</span> {selectedReceipt.store}</p>
                  <p><span className="text-slate-500">Adquirente:</span> {selectedReceipt.clientName}</p>
                  <p><span className="text-slate-500">{selectedReceipt.clientType}:</span> {selectedReceipt.clientDoc}</p>
                </div>

                <div className="border-t border-b border-dashed border-slate-700 py-2 text-[10px]">
                  <div className="flex justify-between font-bold text-slate-500 mb-1">
                    <span>Producto (Qtd)</span>
                    <span>Total</span>
                  </div>
                  <div className="flex justify-between text-white">
                    <span>{selectedReceipt.product} (x{selectedReceipt.quantity})</span>
                    <span className="font-bold">S/ {selectedReceipt.total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-1 text-right text-[11px] pt-1">
                  <div>
                    <span className="text-slate-500 mr-2">Base Gravable:</span>
                    <span>S/ {selectedReceipt.subtotal.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 mr-2">IGV (18.00%):</span>
                    <span>S/ {selectedReceipt.igv.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-slate-800 pt-1 font-bold text-emerald-400">
                    <span className="mr-2">Total Recibido:</span>
                    <span>S/ {selectedReceipt.total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="text-[8px] text-slate-500 text-center pt-2">
                  <p>Autorizado mediante Resolución SUNAT.</p>
                  <p className="font-bold text-emerald-500/80 mt-0.5">Hash: {Math.random().toString(16).slice(2, 10).toUpperCase()}-SUNAT-SEE</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
