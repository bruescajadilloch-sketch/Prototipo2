# SUNAT Sales Security Specification

## 1. Data Invariants
- A sale document must be valid and conform to the SUNAT Schema (Base Imponible, IGV at 18%, and correct totals).
- Formats:
  - Document types must be either `Boleta` or `Factura`.
  - Client document types must be either `DNI` (8 digits) or `RUC` (11 digits).
  - Document numbers must start with `B` for Boleta (e.g. `B001-...`) or `F` for Factura (e.g. `F001-...`).
  - Strict temporal enforcement: `timestamp` is exactly matches request insertion time or is set to creation time.

## 2. Dirty Dozen payloads (Adversarial Tests)
We define the following scenarios which must be rejected by security rules:
1. **Unauthenticated Write**: Creating a Sale document without logged-in session.
2. **Missing Product**: Sale document payload lacks `product` field.
3. **Invalid Price Type**: Price field is a string instead of a number.
4. **Invalid DNI length**: DNI with length of 7 digits indeed of 8 digits.
5. **Invalid RUC format**: RUC containing characters instead of just numeric digits.
6. **Mismatched Invoice Type**: Invoice type is `Factura` but the document number starts with `B`.
7. **Negative Totals**: Subtotal or total values set below zero.
8. **Artificially Injected Field**: Client tries to inject an unauthorized administrative flag `isVerifiedBySunat` in data.
9. **Update Locked Sale**: Client tries to update a completed and locked Invoice/Sale.
10. **Delete Locked Sale**: Client tries to delete a historic sale record.
11. **Spoofed User Identity**: Attempting to insert a sale indicating a user profile not matching client auth.
12. **Insecure Collection Scrape**: Attempting a list query to read sales without proper authorization bounds.

## 3. Test Cases (TDD Draft)
All tests check and enforce:
- Authenticated read of sales: `allow read: if isSignedIn();`
- Authenticated creation of sales: `allow create: if isSignedIn() && isValidSale(request.resource.data);`
- Updates/Deletes: Deny all modifications to historic records (`allow update, delete: if false;`) to ensure auditor immutability of SUNAT-compliant tax records.
